find . -type f,d -printf '.' | wc -c
